﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RGBCosmetics.Models;
using System.Net;
using System.Net.Mail;
using System.IO;

namespace RGBCosmetics.Controllers
{
    public class RGBCosmeticsController : Controller
    {
        string CS = "data source=DESKTOP-7MUH7F7\\SQL2008; database = master; integrated security=SSPI";
        public static int a;
        [HttpGet]
        public ActionResult Login()
        {
            if (a == 0)
            {
                return View();
            }
            else
            {
                ViewBag.Message = "Incorrect Password.";
                return View();
            }

        }


        [HttpPost]
        public ActionResult Index()
        {
            RetUser User = new RetUser();
            User.Email = "";
            User.Name = "";
            User.Surname = "";
            User.Password = "";
            User.Country = "";
            User.FavouriteColour = "";
            User.Birthday = "";
            User.Cellphone = "";
            User.Comments = "";
            return View(User);
        }

        public void CreateUser(string Email, string Name, string Surname, string Password, string Country, string FavouriteColour, DateTime? Birthday, int? Cellphone, string Comments)
        {
            string ID;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlCommand sqlCo = new SqlCommand("sp_ins_users", con);
                sqlCo.CommandType = System.Data.CommandType.StoredProcedure;
                sqlCo.Parameters.AddWithValue("@Email", Email);
                sqlCo.Parameters.AddWithValue("@Name", Name);
                sqlCo.Parameters.AddWithValue("@Surname", Surname);
                sqlCo.Parameters.AddWithValue("@Password", Password);
                sqlCo.Parameters.AddWithValue("@Country", Country);
                sqlCo.Parameters.AddWithValue("@FavouriteColour", FavouriteColour);
                sqlCo.Parameters.AddWithValue("@Birthday", Birthday);
                sqlCo.Parameters.AddWithValue("@Cellphone", Cellphone);
                sqlCo.Parameters.AddWithValue("@Comments", Comments);

                SqlParameter outputParam = new SqlParameter();
                outputParam.ParameterName = "@ID";
                outputParam.SqlDbType = System.Data.SqlDbType.Int;
                outputParam.Direction = System.Data.ParameterDirection.Output;
                sqlCo.Parameters.Add(outputParam);

                con.Open();
                try
                {
                    sqlCo.ExecuteNonQuery();

                    ID = outputParam.Value.ToString();

                    var fromAddress = new MailAddress("rgbcosmetics123@gmail.com", "New User");
                    var toAddress = new MailAddress(Email, "Administrator"); //replaceable with administrators email
                    const string fromPassword = "B335625b";
                    string subject = Name + ' ' + Surname + " User Confirmation";
                    string body = "http://localhost:3898/RGBCosmetics/Index/" + ID;


                    //SmtpClient smtpClient = new SmtpClient();
                    //MailMessage mailMessage = new MailMessage();

                    //mailMessage.Subject = "mailSubject";
                    //mailMessage.Body = "mailBody";

                    //smtpClient.Send(mailMessage);

                    var smtp = new SmtpClient
                    {
                        Host = "smtp.gmail.com",
                        Port = 587,
                        EnableSsl = true,
                        DeliveryMethod = SmtpDeliveryMethod.Network,
                        Credentials = new NetworkCredential(fromAddress.Address, fromPassword),
                        Timeout = 20000
                    };
                    using (var message = new MailMessage(fromAddress, toAddress)
                    {

                        Subject = subject,
                        Body = body
                    })
                    {
                        smtp.Send(message);
                    }
                }
                catch (Exception ex)
                {
                }
            }



        }


        public void GetAccountDetails(string Email)
        {
            string ID;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlCommand sqlCo = new SqlCommand("get_user", con);
                sqlCo.CommandType = System.Data.CommandType.StoredProcedure;
                sqlCo.Parameters.AddWithValue("@Email", Email);

                SqlParameter outputParam = new SqlParameter();
                outputParam.ParameterName = "@ID";
                outputParam.SqlDbType = System.Data.SqlDbType.Int;
                outputParam.Direction = System.Data.ParameterDirection.Output;
                sqlCo.Parameters.Add(outputParam);

                con.Open();
                try
                {
                    sqlCo.ExecuteNonQuery();

                    ID = outputParam.Value.ToString();

                    var fromAddress = new MailAddress("rgbcosmetics123@gmail.com", "New User");
                    var toAddress = new MailAddress(Email, "Administrator"); //replaceable with administrators email
                    const string fromPassword = "B335625b";
                    string subject = "User Account Information";
                    string body = "http://localhost:3898/RGBCosmetics/UserMaintenance/" + ID;


                    //SmtpClient smtpClient = new SmtpClient();
                    //MailMessage mailMessage = new MailMessage();

                    //mailMessage.Subject = "mailSubject";
                    //mailMessage.Body = "mailBody";

                    //smtpClient.Send(mailMessage);

                    var smtp = new SmtpClient
                    {
                        Host = "smtp.gmail.com",
                        Port = 587,
                        EnableSsl = true,
                        DeliveryMethod = SmtpDeliveryMethod.Network,
                        Credentials = new NetworkCredential(fromAddress.Address, fromPassword),
                        Timeout = 20000
                    };
                    using (var message = new MailMessage(fromAddress, toAddress)
                    {

                        Subject = subject,
                        Body = body
                    })
                    {
                        smtp.Send(message);
                    }
                }
                catch (Exception ex)
                {
                }
            }



        }

        public ActionResult Users(string txtEmail, string password)
        {
            if (txtEmail != null && password != null)
            {
                using (SqlConnection con = new SqlConnection(CS))
                {
                    SqlCommand sqlCo = new SqlCommand("UserLogIn", con);
                    sqlCo.CommandType = System.Data.CommandType.StoredProcedure;
                    sqlCo.Parameters.AddWithValue("@Email", txtEmail);
                    sqlCo.Parameters.AddWithValue("@Password", password);
                    con.Open();
                    try
                    {
                        sqlCo.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        a = 1;
                        return RedirectToAction("Login", "RGBCosmetics");
                    }
                }
            }
            List<RetUser> thisUser = new List<RetUser>();
            using (SqlConnection con = new SqlConnection(CS))
            {
                con.Open();
                SqlCommand sqlCo = new SqlCommand("sp_retAllUsers", con);
                sqlCo.CommandType = System.Data.CommandType.StoredProcedure;

                using (SqlDataReader Reader = sqlCo.ExecuteReader())
                {
                    while (Reader.Read())
                    {
                        thisUser.Add(new RetUser()
                        {
                            Email = Reader["Email"].ToString(),
                            Name = Reader["Name"].ToString(),
                            Surname = Reader["Surname"].ToString(),
                            Password = Reader["Password"].ToString(),
                            Country = Reader["CountryCode"].ToString(),
                            FavouriteColour = Reader["FavouriteColour"].ToString(),
                            Birthday = Reader["Birthday"].ToString(),
                            Cellphone = Reader["Cellphone"].ToString(),
                            Comments = Reader["Comments"].ToString()
                        });
                    }
                }
            }
            return View(thisUser);
        }

        [HttpGet]
        public ActionResult UserMaintenance(int? ID, string txtEmail, string password)
        {
            if (ID == null)
            {
                RetUser User = new RetUser();
                User.Email = "";
                User.Name = "";
                User.Surname = "";
                User.Password = "";
                User.Country = "";
                User.FavouriteColour = "";
                User.Birthday = "";
                User.Cellphone = "";
                User.Comments = "";
                return View(User);
            }
            RetUser thisUser = new RetUser();
            using (SqlConnection con = new SqlConnection(CS))
            {
                con.Open();
                SqlCommand sqlCo = new SqlCommand("sp_retAllUsers", con);
                sqlCo.CommandType = System.Data.CommandType.StoredProcedure;

                using (SqlDataReader Reader = sqlCo.ExecuteReader())
                {
                    DataTable table = new DataTable();
                    table.Columns.Add("Email");
                    table.Columns.Add("Name");
                    table.Columns.Add("Surname");
                    table.Columns.Add("Password");
                    table.Columns.Add("CountryCode");
                    table.Columns.Add("FavouriteColour");
                    table.Columns.Add("Birthday");
                    table.Columns.Add("Cellphone");
                    table.Columns.Add("Comments");

                    while (Reader.Read())
                    {
                        thisUser = new RetUser();
                        thisUser.Email = Reader["Email"].ToString();
                        thisUser.Name = Reader["Name"].ToString();
                        thisUser.Surname = Reader["Surname"].ToString();
                        thisUser.Password = Reader["Password"].ToString();
                        thisUser.Country = Reader["CountryCode"].ToString();
                        thisUser.FavouriteColour = Reader["FavouriteColour"].ToString();
                        thisUser.Birthday = Reader["Birthday"].ToString();
                        thisUser.Cellphone = Reader["Cellphone"].ToString();
                        thisUser.Comments = Reader["Comments"].ToString();


                        DataRow dataRow = table.NewRow();
                        dataRow["Email"] = Reader["Email"];
                        dataRow["Name"] = Reader["Name"];
                        dataRow["Surname"] = Reader["Surname"];
                        dataRow["Password"] = Reader["Password"];
                        dataRow["CountryCode"] = Reader["CountryCode"];
                        dataRow["FavouriteColour"] = Reader["FavouriteColour"];
                        dataRow["Birthday"] = Reader["Birthday"];
                        dataRow["Cellphone"] = Reader["Cellphone"];
                        dataRow["Comments"] = Reader["Comments"];
                        table.Rows.Add(dataRow);
                    }
                }
            }
            return View(thisUser);
        }

        public void export()
        {
            List<RetUser> thisUser = new List<RetUser>();
            using (SqlConnection con = new SqlConnection(CS))
            {
                con.Open();
                SqlCommand sqlCo = new SqlCommand("sp_retAllUsers", con);
                sqlCo.CommandType = System.Data.CommandType.StoredProcedure;

                using (SqlDataReader Reader = sqlCo.ExecuteReader())
                {
                    while (Reader.Read())
                    {
                        thisUser.Add(new RetUser()
                        {
                            Email = Reader["Email"].ToString(),
                            Name = Reader["Name"].ToString(),
                            Surname = Reader["Surname"].ToString(),
                            Password = Reader["Password"].ToString(),
                            Country = Reader["CountryCode"].ToString(),
                            FavouriteColour = Reader["FavouriteColour"].ToString(),
                            Birthday = Reader["Birthday"].ToString(),
                            Cellphone = Reader["Cellphone"].ToString(),
                            Comments = Reader["Comments"].ToString()
                        });
                    }
                }
            }

            StringWriter sw = new StringWriter();
            sw.WriteLine("\"Email\",\"Name\",\"Surname\",\"Password\",\"Country\",\"FavouriteColour\",\"Birthday\",\"Cellphone\",\"Comments\",");

            foreach (var user in thisUser)
            {
                sw.WriteLine(string.Format("\"{0}\",\"{1}\",\"{2}\",\"{3}\",\"{4}\",\"{5}\",\"{6}\",\"{7}\",\"{8}\"",
                    user.Email,
                    user.Name,
                    user.Surname,
                    user.Password,
                    user.Country,
                    user.FavouriteColour,
                    user.Birthday,
                    user.Cellphone,
                    user.Comments));
            }

            Response.AddHeader("Content-Disposition", "attachment; filename=internal-users.csv");
            Response.ContentType = "text/csv";
            Response.ContentEncoding = System.Text.Encoding.GetEncoding("utf-8");
            Response.Write(sw);
            Response.End();
        }
    }
}
