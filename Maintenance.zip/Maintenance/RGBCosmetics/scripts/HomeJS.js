﻿

var controllerName = "RGBCosmetics";


function validate(evt) {
    var theEvent = evt || window.event;

    // Handle paste
    if (theEvent.type === 'paste') {
        key = event.clipboardData.getData('text/plain');
    } else {
        // Handle key press
        var key = theEvent.keyCode || theEvent.which;
        key = String.fromCharCode(key);
    }
    var regex = /[0-9]|\./;
    if (!regex.test(key)) {
        theEvent.returnValue = false;
        if (theEvent.preventDefault) theEvent.preventDefault();
    }
}
///////////////////////////////////////////////////////////////////////////////////////
$(document).ready(function () {
    //your code here
    $('#btnCreate').on("click", function (e) {
        //  e.preventDefault();

        var Email = '';
        var Name = '';
        var Surname = '';
        var Password = '';
        var PasswordC = '';
        var Country = '';
        var FavouriteColour = '';
        var Birthday = '';
        var Cellphone = '';
        var Comments = '';

        Email = $("input[name=Email]").val();
        Name = $("input[id=Name]").val();
        Surname = $("input[id=Surname]").val();
        Password = $("input[name=up]").val();
        PasswordC = $("input[name=up2]").val();
        Country = $("#Country option:selected").val();

        try
        {
            if (document.getElementById('ColourRed').checked) {
                FavouriteColour = "Red"
            } else if (document.getElementById('ColourGreen').checked) {
                FavouriteColour = "Green"
            } else if (document.getElementById('ColourBlue').checked) {
                FavouriteColour = "Blue"
            }
        }
        catch(err)
        {
            FavouriteColour = "None"
        }
        Birthday = $("input[name=Birthday]").val();
        Cellphone = $("input[name=Cellphone]").val();
        Comments = $("input[name=Comments]").val();

        if (Name == "") {
            
            Swal.fire({type: 'error',title: 'Oops...',text: 'Please edit a Name!'})
            return;
        }
        if (Surname == "") {
            Swal.fire({ type: 'error', title: 'Oops...', text: 'Please edit a Surname!' })
            return;
        }
        if (Password == "") {
            Swal.fire({ type: 'error', title: 'Oops...', text: 'Please edit a Password!' })
            return;
        }
        if (Password != PasswordC)
        {
            Swal.fire({ type: 'error', title: 'Oops...', text: 'Passwords do not match!' })
            return;
        }
        if (Country == "") {
            Swal.fire({ type: 'error', title: 'Oops...', text: 'Please edit a Country!' })
            return;
        }

         
         
        
         
         
         
        
         

        var Success = function () {
            location.reload();
        


            document.getElementById('clientid').readonly = true;
            shouldRefresh = true;

        }

        var actionmet = location.href;
        var index = actionmet.lastIndexOf(controllerName);
        actionmet = actionmet.substr(0, index) + controllerName + '/CreateUser';
        shouldRefresh = true;
        $.ajax(
            {
                url: actionmet,
                data: " { 'Email': '" + Email + "','Name':'" + Name + "','Surname': '" + Surname + "','Password': '" + Password + "','Country': '" + Country + "','FavouriteColour': '" + FavouriteColour + "','Birthday': '" + Birthday + "','Cellphone': '" + Cellphone + "','Comments': '" + Comments + "' } ",
                type: 'POST',
                contentType: "application/json; charset=utf-8",
                dataType: 'text',
                success: function () {
                    Swal.fire({ type: 'success', title: 'Success', text: 'User Created!' })

                },
                fail: function (xhr, ajaxOptions, thrownError) {
                    alert("Ajax Failed!!!");

                }

            });
        //swal("", "Update successful", "success");
        //window.location.reload();
        //$('#myModal').modal('hide');
        //$('#AddmyModal').modal('hide');
        //shouldRefresh = true;
    });

})