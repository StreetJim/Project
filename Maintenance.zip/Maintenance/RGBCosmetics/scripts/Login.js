﻿
var controllerName = "RGBCosmetics";
$(document).ready(function () {
    //your code here
    $('#Login').on("click", function (e) {
        //  e.preventDefault();

        var txtEmail = '';
        var password = '';

        txtEmail = $("input[id=txtEmail]").val();
        password = $("input[id=password]").val();

        var Success = function () {
            location.reload();
            document.getElementById('clientid').readonly = true;
            shouldRefresh = true;
        }

        var actionmet = location.href;
        var index = actionmet.lastIndexOf(controllerName);
        actionmet = actionmet.substr(0, index) + controllerName + '/Users';
        return;
        //$.ajax(
        //    {
        //        url: actionmet,
        //        data: " { 'txtEmail': '" + txtEmail + "','password':'" + password + "' } ",
        //        type: 'POST',
        //        contentType: "application/json; charset=utf-8",
        //        dataType: 'text',
        //        fail: function (xhr, ajaxOptions, thrownError) {
        //            alert("Ajax Failed!!!");

        //        }

        //    });
        //swal("", "Update successful", "success");
        //window.location.reload();
        //$('#myModal').modal('hide');
        //$('#AddmyModal').modal('hide');
        //shouldRefresh = true;
    });

    $('#btnCheck').on("click", function (e) {
        //  e.preventDefault();

        var Email = '';

        Email = $("input[id=Email]").val();
        var Success = function () {
            location.reload();
            document.getElementById('clientid').readonly = true;
            shouldRefresh = true;
        }

        var actionmet = location.href;
        var index = actionmet.lastIndexOf(controllerName);
        actionmet = actionmet.substr(0, index) + controllerName + '/Users';
        return;
        //$.ajax(
        //    {
        //        url: actionmet,
        //        data: " { 'txtEmail': '" + txtEmail + "','password':'" + password + "' } ",
        //        type: 'POST',
        //        contentType: "application/json; charset=utf-8",
        //        dataType: 'text',
        //        fail: function (xhr, ajaxOptions, thrownError) {
        //            alert("Ajax Failed!!!");

        //        }

        //    });
        //swal("", "Update successful", "success");
        //window.location.reload();
        //$('#myModal').modal('hide');
        //$('#AddmyModal').modal('hide');
        //shouldRefresh = true;
    });

    $('#btnCreate').on("click", function (e) {
        //  e.preventDefault();

        var Email = '';
        
        Email = $("input[name=Email]").val();
        
        if (Email == "") {
            
            Swal.fire({type: 'error',title: 'Oops...',text: 'Please edit a Email!'})
            return;
        }
        var actionmet = location.href;
        var index = actionmet.lastIndexOf(controllerName);
        actionmet = actionmet.substr(0, index) + controllerName + '/CreateUser';
        shouldRefresh = true;
        $.ajax(
            {
                url: actionmet,
                data: " { 'Email': '" + Email + "','Name':'" + Name + "','Surname': '" + Surname + "','Password': '" + Password + "','Country': '" + Country + "','FavouriteColour': '" + FavouriteColour + "','Birthday': '" + Birthday + "','Cellphone': '" + Cellphone + "','Comments': '" + Comments + "' } ",
                type: 'POST',
                contentType: "application/json; charset=utf-8",
                dataType: 'text',
                success: function () {
                    Swal.fire({ type: 'success', title: 'Success', text: 'User Created!' })

                },
                fail: function (xhr, ajaxOptions, thrownError) {
                    alert("Ajax Failed!!!");

                }

            });
    });
})